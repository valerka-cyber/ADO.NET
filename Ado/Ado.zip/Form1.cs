﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Practices.Unity;

namespace Ado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            model.Firm firm = Program.DiContainer.Resolve<model.Firm>();
            var query = from d in firm.Departments
                        join m in firm.Managers
                        on d.Id equals m.Id_main_dep
                        where m.SurName.Contains('a')
                        select new { Dep = d, Man = m };

            foreach (var obj in query)
            {
                listBox1.Items.Add(
                    obj.Man.SurName + "  "
                    + obj.Dep.Name);
            }
            //MessageBox.Show("Dep / Man:" + query.Count());
        }
    }
}
