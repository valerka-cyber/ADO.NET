﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ado.model
{
   public  class Departmen
    {
        public Guid  Id { get; set; } 
        public String  Name { get; set; }

    }
}
